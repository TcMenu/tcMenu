## Data Directory
This directory will usually contain data files used by the app at runtime. It's copied by the maven build script at compile time into the deployment directory.

If you are using EmbedControlJS then you simply copy all the output files from the latest release into the `www` directory to update it, generally speaking it will always work with the latest Java API. 
